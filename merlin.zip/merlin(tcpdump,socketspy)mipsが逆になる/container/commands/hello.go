package commands

import (
	"fmt"

	structs "github.com/MythicMeta/MythicContainer/agent_structs"

	"github.com/Ne0nd0g/merlin-message/jobs"
)

func hello() structs.Command {
	attr := structs.CommandAttribute{
		SupportedOS: []string{structs.SUPPORTED_OS_WINDOWS, structs.SUPPORTED_OS_LINUX, structs.SUPPORTED_OS_MACOS, "freebsd", "openbsd", "solaris"},
	}
	command := structs.Command{
		Name:                           "hello",
		NeedsAdminPermissions:          false,
		HelpString:                     "hello",
		Description:                    "practice command added by me",
		Version:                        0,
		Author:                         "@you",
		MitreAttackMappings:            []string{},
		ScriptOnlyCommand:              false,
		CommandAttributes:              attr,
		TaskFunctionCreateTasking:      helloCreateTask,
		TaskFunctionParseArgString:     taskFunctionParseArgString,
		TaskFunctionParseArgDictionary: taskFunctionParseArgDictionary,
	}
	return command
}

func helloCreateTask(task *structs.PTTaskMessageAllData) (resp structs.PTTaskCreateTaskingMessageResponse) {
	pkg := "mythic/container/commands/hello/helloCreateTask()"
	resp.TaskID = task.Task.ID
	job := jobs.Command{Command: task.Task.CommandName}
	mythicJob, err := ConvertMerlinJobToMythicTask(job, jobs.NATIVE)
	if err != nil {
		resp.Error = fmt.Sprintf("%s: %s", pkg, err)
		resp.Success = false
		return
	}
	task.Args.SetManualArgs(mythicJob)
	resp.Success = true
	return
}
