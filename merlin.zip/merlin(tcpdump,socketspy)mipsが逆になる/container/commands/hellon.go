package commands

import (
	"fmt"
	"strconv"

	structs "github.com/MythicMeta/MythicContainer/agent_structs"
	"github.com/MythicMeta/MythicContainer/logging"

	"github.com/Ne0nd0g/merlin-message/jobs"
)

func hellon() structs.Command {
	attr := structs.CommandAttribute{
		SupportedOS: []string{structs.SUPPORTED_OS_WINDOWS, structs.SUPPORTED_OS_LINUX, structs.SUPPORTED_OS_MACOS, "freebsd", "openbsd", "solaris"},
	}

	// ★引数の宣言：count という数値パラメータ（UIのフォームに出る）
	count := structs.CommandParameter{
		Name:             "count",
		ModalDisplayName: "count",
		CLIName:          "count",
		ParameterType:    structs.COMMAND_PARAMETER_TYPE_NUMBER, // 数値型
		Description:      "How many times to repeat the hello line",
		ParameterGroupInformation: []structs.ParameterGroupInfo{
			{ParameterIsRequired: true, GroupName: "Default", UIModalPosition: 0},
		},
	}

	command := structs.Command{
		Name:                           "hellon",
		NeedsAdminPermissions:          false,
		HelpString:                     "hellon 5",
		Description:                    "practice command: return the hello line N times",
		Version:                        0,
		Author:                         "@you",
		MitreAttackMappings:            []string{},
		ScriptOnlyCommand:              false,
		CommandAttributes:              attr,
		CommandParameters:              []structs.CommandParameter{count}, // ↑のcountを紐付け
		TaskFunctionCreateTasking:      hellonCreateTask,
		TaskFunctionParseArgString:     taskFunctionParseArgString,     // commands.goの共通ヘルパ
		TaskFunctionParseArgDictionary: taskFunctionParseArgDictionary, // 同上
	}
	return command
}

// 実行時に頭脳側で走る：countを取り出し、体へ渡すジョブ(Args=["5"]など)を組み立てる
func hellonCreateTask(task *structs.PTTaskMessageAllData) (resp structs.PTTaskCreateTaskingMessageResponse) {
	pkg := "mythic/container/commands/hellon/hellonCreateTask()"
	resp.TaskID = task.Task.ID

	count, err := task.Args.GetNumberArg("count") // UIで入れた数値を取得(float64で来る)
	if err != nil {
		err = fmt.Errorf("%s: there was an error getting the 'count' argument: %s", pkg, err)
		resp.Error = err.Error()
		resp.Success = false
		logging.LogError(err, "returning with error")
		return
	}

	countStr := strconv.Itoa(int(count)) // 体へは文字列配列で渡すので "5" に変換

	job := jobs.Command{
		Command: task.Task.CommandName, // = "hellon"
		Args:    []string{countStr},    // = ["5"] → 体側の cmd.Args[0]
	}

	mythicJob, err := ConvertMerlinJobToMythicTask(job, jobs.NATIVE) // NATIVEコマンドとして体へ
	if err != nil {
		err = fmt.Errorf("%s: there was an error converting the Merlin job to a Mythic task: %s", pkg, err)
		resp.Error = err.Error()
		resp.Success = false
		logging.LogError(err, "returning with error")
		return
	}

	task.Args.SetManualArgs(mythicJob)

	resp.DisplayParams = &countStr // タスク一覧に "5" と表示
	resp.Success = true
	return
}
